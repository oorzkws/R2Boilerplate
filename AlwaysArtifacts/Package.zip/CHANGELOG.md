## 1.0.0
* Initial version

## 1.0.1
* Perform override within RunArtifactManager to avoid race conditions in Run.Start

## 1.0.2
* Take precautions to prevent artifacts from applying multiple times to the same run