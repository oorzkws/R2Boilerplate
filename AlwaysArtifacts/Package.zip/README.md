# Always Artifacts

Enforce your favorite artifacts always being enabled, even in Eclipse!

Not tested in MP, please report any issues.

## Changelog

**1.0.2**
* Take precautions to prevent artifacts from applying multiple times to the same run

**1.0.1**
* Perform override within RunArtifactManager to avoid race conditions in Run.Start

**1.0.0**
* Initial version
